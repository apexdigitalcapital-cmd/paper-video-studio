#!/bin/bash
# Usage: site_media.sh <id> [site_dir]
# Makes the Paper Academy web player files for one paper from its spec, using the v2 voice:
#   <site>/data/<id>.js   (spec + timeline + voice envelope for the in-browser stage)
#   <site>/audio/<id>.mp3 (narration + music, bitrate chosen to stay under 14.5 MB)
# Reuses work/<id> audio when it already exists (e.g. after a video build).
set -e; ID=$1; SITE=${2:-/home/claude/site}; T=$(cd $(dirname "$0"); pwd); S=$T/..
W=$S/work/$ID; SPEC=$S/specs/$ID.json; mkdir -p $W $SITE/data $SITE/audio
if [ ! -s $W/mix.wav ] || ! grep -q v2-natural $W/timeline.json 2>/dev/null; then
  python3 $T/make_voice.py $SPEC $W > $W/voice.log 2>&1
  bash $T/audio.sh $W > /dev/null
fi
[ -s $W/data.js ] || python3 $T/prep.py $SPEC $W > /dev/null
cp $W/data.js $SITE/data/$ID.js
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 $W/mix.wav)
BR=$(python3 -c "print(max(32, min(64, int(14.5*8*1024/$DUR))))")
ffmpeg -y -loglevel error -i $W/mix.wav -ac 1 -ar 44100 -c:a libmp3lame -b:a ${BR}k $SITE/audio/$ID.mp3
echo "$ID $(python3 -c "print(round($DUR/60,1))") min ${BR}k $(du -h $SITE/audio/$ID.mp3 | cut -f1)"
