"""Usage: python3 prep.py <spec.json> <workdir> [max_part_sec=330]
Writes engine data file (<workdir>/data.js) and parts.json: contiguous chapter groups,
each <= max_part_sec, so every delivered MP4 stays under the 30 MB upload cap."""
import json, sys, numpy as np, soundfile as sf
spec = json.load(open(sys.argv[1])); wd = sys.argv[2]; mx = float(sys.argv[3]) if len(sys.argv) > 3 else 330
tl = json.load(open(f"{wd}/timeline.json"))
a, sr = sf.read(f"{wd}/voice.wav"); a = a.mean(1) if a.ndim > 1 else a
fps = 30; hop = sr // fps; n = len(a) // hop
env = np.array([np.sqrt(np.mean(a[i*hop:(i+1)*hop]**2)) for i in range(n)])
env = np.clip(env / (np.percentile(env, 98) + 1e-9), 0, 1); out = np.zeros_like(env); v = 0
for i, e in enumerate(env): v += (e - v) * (0.6 if e > v else 0.18); out[i] = v
open(f"{wd}/data.js", "w").write("window.SPEC=" + json.dumps(spec) + ";\nwindow.TL=" + json.dumps(tl) + ";\nwindow.ENV=" + json.dumps([round(float(x), 3) for x in out]) + ";")
parts, cur = [], None
for i, s in enumerate(tl["scenes"]):
    if cur and (s["start"] + s["dur"] - cur["from"]) > mx:
        parts.append(cur); cur = None
    if not cur: cur = {"from": s["start"], "chapters": []}
    cur["chapters"].append(i); cur["to"] = s["start"] + s["dur"]
parts.append(cur); parts[-1]["to"] = tl["total"]
for k, p in enumerate(parts):
    p["n"] = k + 1; p["from"] = round(p["from"], 3); p["to"] = round(p["to"], 3)
    p["label"] = f"Part {k+1} of {len(parts)} — " + ", ".join(spec["chapters"][c].get("label", "") for c in p["chapters"][:3]) + ("…" if len(p["chapters"]) > 3 else "")
json.dump(parts, open(f"{wd}/parts.json", "w"), indent=1)
for p in parts: print(p["n"], round((p["to"] - p["from"]) / 60, 2), "min", p["label"])
