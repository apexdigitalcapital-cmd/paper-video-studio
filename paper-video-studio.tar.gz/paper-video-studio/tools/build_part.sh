#!/bin/bash
# Usage: build_part.sh <workdir> <part_n> <out_name_prefix>
# Renders one part (two parallel halves), muxes its audio slice -> <workdir>/out/<prefix>_PartN.mp4
set -e; WD=$1; N=$2; PFX=$3; T=$(cd $(dirname "$0"); pwd)
read FROM TO < <(python3 -c "import json;p=json.load(open('$WD/parts.json'))[$N-1];print(p['from'],p['to'])")
MID=$(python3 -c "print(round(($FROM+$TO)/2,3))")
mkdir -p $WD/out $WD/tmp
cd $T && node render.mjs $WD/stage.html video $FROM $MID $WD/tmp/p${N}a.mp4 > $WD/tmp/p${N}a.log 2>&1 &
cd $T && node render.mjs $WD/stage.html video $MID $TO $WD/tmp/p${N}b.mp4 > $WD/tmp/p${N}b.log 2>&1 &
wait
printf "file 'p${N}a.mp4'\nfile 'p${N}b.mp4'\n" > $WD/tmp/l$N.txt
DUR=$(python3 -c "print(round($TO-$FROM,3))")
ffmpeg -y -loglevel error -f concat -safe 0 -i $WD/tmp/l$N.txt -ss $FROM -t $DUR -i $WD/mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 96k -af "afade=t=in:d=0.4,afade=t=out:st=$(python3 -c "print(max(0,$DUR-1.2))"):d=1.2" -movflags +faststart -shortest $WD/out/${PFX}_Part${N}.mp4
ls -la $WD/out/${PFX}_Part${N}.mp4
