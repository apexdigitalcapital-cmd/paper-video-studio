# Paper Video Studio pipeline

KJ's research-paper explainer video pipeline (narrated, animated MP4s in parts under 30 MB).

- `RUNBOOK.md` — the step-by-step procedure and quality standards.
- `engine/stage.html` — animation engine; `site/` — Paper Academy web player copy + LTF guides.
- `tools/` — voice (Kokoro v2 blend), music/mix, prep, render, part builder.
- `specs/<id>.json` — finished scene scripts.

Setup (one time per session), run as separate commands:

    pip install --break-system-packages kokoro-onnx soundfile scipy
    mkdir -p models && curl -sSL -o models/kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
    curl -sSL -o models/voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
    cd tools && npm i puppeteer-core @sparticuz/chromium @fontsource/inter @fontsource/jetbrains-mono
