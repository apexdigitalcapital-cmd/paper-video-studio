# Paper Video Studio — Runbook

Standing job for KJ: turn each research paper in the queue into an in-depth, narrated,
animated explainer video (10–45 min, as long as the paper needs), in the house style
(black background, orange #ff7a1a accent, dotted orb, Inter + JetBrains Mono, British
"Jarvis" narrator = Kokoro voice blend bm_george 70% + bm_fable 30%, speed 1.0, "v2-natural"
narration: spoken a few sentences at a time with varied pauses, light processing, no echo). Coverage must match the paper — the viewer should
not need to read the paper to know what is in it.

Home base: the private Artifact **"Paper Video Studio"** (URL kept in the scheduled task prompt).
- Its database collection `papers` holds the queue: one doc per paper (`p01`…), fields
  `order, title, url, desc, status, minutes, parts_total, parts_sent, spec_path, source, notes,
  lock_until, updated`.
- `status`: `queued` → `scripting` → `rendering` → `done` (or `needs_pdf` if no full text).
- Its published files hold this pipeline (`pipeline/…`) and each finished script (`specs/<id>.json`).

PDFs: Google Drive folder **"Paper Video Studio — PDFs"** (id `1ccNdJJnVRJcHYbLSsyyp3AWOSGutBr2b`).
KJ drops PDFs there. The shell cannot download from university/SSRN sites.

---------------------------------------------------------------------------------------------
## Each run, in order

1. **Restore pipeline** (fresh sessions start empty):
   `Artifact read` the studio URL with `paths` = every file listed under `pipeline/` (use
   `action:list, scope:files` first). Copy them into `/home/claude/studio/` keeping the
   sub-paths (`engine/stage.html`, `tools/*`, `RUNBOOK.md`). Then `bash /home/claude/studio/tools/setup.sh`.
   If `/home/claude/studio/tools/setup.sh` already exists and works, skip the restore.
2. **Pick work**: `ArtifactData query` collection `papers`. Priority:
   a. a doc in `rendering` whose `lock_until` has passed (a previous run died) → resume it;
   a2. else a `done` doc with `revoice: true` and expired lock → re-voice it (see Re-voice rule);
   b. else the lowest `order` doc in `scripting` with expired lock, else lowest `queued`.
   Skip docs whose lock is still live (another run is on it).
   Set `status`, `lock_until = now + 5h`, `updated` before starting.
3. **Get the full text** (never script from an abstract or a summary alone):
   a. Google Drive: if the queue doc has `drive_pdf`, call `read_file_content` with that file id.
      Otherwise `search_files` with `parentId = '1ccNdJJnVRJcHYbLSsyyp3AWOSGutBr2b'` (page through
      `nextPageToken`) and match the PDF's file name to the URL's file name; store the id
      as `drive_pdf`. Re-check Drive at the start of every run: KJ adds PDFs over time. If the read looks truncated, note which
      sections are missing.
   b. Else `WebFetch` the URL several times, each prompt asking for ONE part of the paper
      (e.g. "sections 1–2 in detail", "every number in Table II", "section 5 and conclusion"),
      until every section, table and figure is covered. Record in `notes` which parts came
      through.
   c. SSRN / record pages that only expose an abstract: if no PDF in Drive, set
      `status: needs_pdf`, tell KJ in one line (via SendUserMessage) to drop that PDF in the
      Drive folder, and move to the next paper.
3b. **Companion YouTube deep dive (mandatory for every paper).**
   - Find candidates: `WebSearch` with `allowed_domains: ["youtube.com"]`, 2–4 queries (paper
     title; authors + "talk"/"seminar"; the core concept, e.g. "weekend theta decay options").
     Prefer, in order: the authors' own talk or conference presentation; an academic or
     professional explainer; a reputable trading educator. At least ~8 minutes. Skip Shorts,
     hype, and course pitches.
   - **Never WebFetch youtube.com** (it rate-limits this workspace). Get the transcript with
     `WebFetch https://youtubetotranscript.com/transcript?v=<VIDEO_ID>`; for long videos ask
     for the first, middle and last third in separate prompts, each as a detailed paraphrased
     walkthrough. If a transcript is unavailable, try the next candidate (try at least 3).
   - Deep dive: list where the video agrees with the paper, adds practical context,
     oversimplifies, or contradicts it, and what the paper's evidence says about each point.
   - Use it: add 2–4 "Second opinion" chapters after the main results and before the
     implications, crediting the video on screen ("Companion video: <title> · <channel>").
     Weave short cross-references elsewhere where they help. Paraphrase only; at most one
     quote under 15 words. Add the video credit to the closing citation.
   - Save `youtube: {id, title, channel, url}` on the queue doc.
4. **Write the script** as `specs/<id>.json` (schema below). Standards:
   - Walk the paper in its own order: motivation & literature → hypotheses/model → data &
     sample construction → methodology → every main table → every figure → every robustness
     test → alternative explanations → mechanism → implications/limitations → conclusion.
   - Every table and figure gets at least one chapter showing its actual numbers
     (bars / table / line). Big tables: show the key rows, say what the rest show.
   - Define every term on first use (theta, delta-hedged, variance risk premium, t-stat…).
   - **Never invent numbers.** If a value isn't in the source text, describe it qualitatively;
     schematic visuals must say "schematic" on screen.
   - Paraphrase; no verbatim passages from the paper (quotes under 15 words, rare).
   - Length: as long as coverage needs, 10–45 min. Rough guide ≈ 1 min per 1–1.5 pages of
     substantive content. Chapters of 20–60 s each; split long sections into several chapters.
   - Narrator voice: calm, precise, lightly witty British butler. "sir" at most 3 times.
   - **Write for the ear** (KJ approved the v2 voice on 13 Oct 2026): short sentences, contractions,
     at most one or two numbers per sentence, round where the screen shows the exact figure
     ("about half a percent" while the card shows 0.488%), commas and dashes for breathing points,
     and an occasional short punchy line ("Eighty percent. From eight days.") that gets its own pause.
     In `say`, write numbers as spoken words ("minus zero point six eight percent",
     "t statistic of minus seven point nine"); use `{"say":..., "show":...}` when the
     subtitle should show digits.
   - Open with a cold-open hook chapter, then a `hero` title chapter (title, journal, year,
     authors as cards). Close with a `close` chapter + full citation + "Educational only —
     not financial advice."
   - Add a "What this means for traders" chapter grounded only in what the paper supports,
     plus the paper's own stated limitations.
   - **Give every video its own look.** Set `"theme": {"accent": "#hex", "accent2": "#hex"}`
     in the spec (accent drives the orb, voice ring, headings, charts, grid; accent2 the second
     background glow). Pick a palette that suits the paper's subject and differs from the
     previous video's (check the other specs' themes). Good accents on black: ember orange
     #ff7a1a, electric cyan #35c8ff, signal violet #9b7bff, gold #f2c14e, mint #4fe0b0,
     rose #ff5c8a, ice blue #8fb4ff, lime #b6f24a. Keep green/amber/coral for good/neutral/bad
     meaning in charts; never use the accent for "bad". Also vary `broll` backdrops across
     chapters (candles, chain, wave, surface) where they fit the content.
   Publish the spec to the studio artifact as `specs/<id>.json` (files map) so a crash
   does not lose it; set `spec_path`.
5. **Produce**:
   ```
   W=/home/claude/studio/work/<id>
   bash /home/claude/studio/tools/new_paper.sh /home/claude/studio/specs/<id>.json $W
   ```
   Preview: render stills at ~85 % of every chapter (`node tools/render.mjs $W/stage.html
   stills t1,t2,... $W/stills`), contact-sheet them, LOOK at them, fix overlaps/overflow in
   the spec (shorter text, `titleSize`, fewer cards), re-run `prep.py` + copy stage if changed.
   Then for each part n in `parts.json` (≤ 5.5 min each so files stay < 30 MB):
   ```
   nohup bash /home/claude/studio/tools/build_part.sh $W n <ShortName> > $W/part_n.log 2>&1 &
   ```
   Build parts one at a time (each uses both CPU cores). Render speed ≈ 3.5–4 min per
   minute of video. Run long builds in the background and poll with short sleeps (<10 min).
6. **Deliver each part as soon as it exists**: `SendUserFile` (status `proactive`,
   caption "<Title> — Part n of N: <chapters>"). Check size < 30 MB first; if over, re-encode
   that part with `-b:v 360k`. Update `parts_sent`, `lock_until`, `updated` after each send.
   Resuming: parts ≤ `parts_sent` are already with KJ — regenerate audio (deterministic) and
   build only the remaining parts.
7. **Questions (mandatory)**: write 15–30 questions for the paper into the **Paper Question
   Vault** artifact https://claude.ai/artifact/5RjVY6zFv1VcGYuGwh1KNq — `ArtifactData set`,
   collection `papers`, doc id = queue id, `file_path` = a JSON file shaped like this:
   `{order, title, authors, journal, year, theme:{accent}, video:{title, channel, url},
   questions:[{id:"q01", section, difficulty:1-3, q, options:[4 strings], answer:<index>,
   explain, visual}]}`. Use the same accent as the video. Cover every section (setup, data,
   method, each main result, robustness, mechanism, risk, implications) plus 2–4 questions
   on the companion video's perspective vs the paper. Every number comes from the paper.
   Vary the correct option's position. Give most questions a `visual`, one of:
   `{kind:"bars", labels[], values[] | series[{name,values[],color}], unit, dec}`,
   `{kind:"line", x[], series[...]}`, `{kind:"stat", value, label}`,
   `{kind:"compare", left:{label,value}, right:{label,value}, unit, dec}`,
   `{kind:"formula", text, label}`, `{kind:"timeline", events[{date,label}]}`, or
   `{icon: calendar|clock|gamma|decay|hedge|scale|bell|up|down|fed|gold|bond|wave|pin|vix|earnings|orb}`.
   A question may omit `options` to become an open "show the answer" card. Markdown `**bold**`
   works in q and explain. Check the write with one `ArtifactData get`.
8. **Finish**: `status: done`, `voice: "v2"`, `minutes`, clear lock. Add the paper to the Paper Academy
   site (section below). Then start the next paper if time
   allows. End the run with one short summary message.

---------------------------------------------------------------------------------------------
## Re-voice rule (KJ, 13 Oct 2026: "fix everything from before")

Videos rendered before the v2 voice (doc field `voice` missing or not "v2") are re-rendered in full
from their existing spec with the current pipeline, and sent again as replacement parts.
- Docs to re-voice carry `revoice: true`. Only act on them once `status` is `done`.
- Lock the doc (lock_until now + 5 h), then build exactly as step 5 (new audio → new timings; the
  spec is unchanged unless a layout fix is needed). Send every part with caption
  "<Title> — NEW VOICE — Part n of N: <chapters>". Track progress in `revoice_parts_sent` /
  `revoice_parts_total`; a resumed run skips parts already sent.
- When all parts are sent: `revoice: false`, `voice: "v2"`, `minutes` = new length, clear lock.
- Every paper rendered with the v2 pipeline from the start gets `voice: "v2"` when done.
- Include any `specs/<id>_addendum.json` addendum in the re-voice.

---------------------------------------------------------------------------------------------
## Paper Academy site (KJ, 13 Oct 2026) — keep it current every run

KJ's study site: Artifact **"Paper Academy"** https://claude.ai/artifact/FvZ2pWJVjwzau1A2y6iJi1
It plays every paper in the browser (the same stage engine + v2 narration), pauses at key ideas and
opens a concept card (simple explanation → deeper detail → how it fits LTF, with LTF guide links).
Published files: `index.html` (page), `stage.html` (web copy of the engine = `pipeline/site/stage.html`),
`concepts.js` (concept cards), `papers.js` (manifest + cues), `data/<id>.js`, `audio/<id>.mp3`.

After a paper is `done` (and after every re-voice), add or refresh it on the site:
1. `bash /home/claude/studio/tools/site_media.sh <id> /home/claude/site` → `data/<id>.js` + `audio/<id>.mp3`
   (reuses `work/<id>` v2 audio; mp3 stays under 15 MB).
2. `Artifact read` the site URL (no path) to get its saved page file, and `read` with `paths`
   `["papers.js","concepts.js"]`. In `papers.js` add/refresh the entry `{id, order, title, authors,
   venue, year, url, desc, cues:[[chapterIndex, conceptId], …]}` — 2–6 cues on the chapters where a
   key idea is first explained. Cue chapter indices must match the spec used to build `data/<id>.js`.
3. If a key idea has no card in `concepts.js`, add one in the same shape (`id, name, tag, anim, simple,
   deep[], formula?, ltf:{text, rules[], links[guide slugs]}`). `anim` is one of: decay, hedge, curve,
   intraday, twolines, premium, gauge, pin, bars, drift, ycurve, bell, scatter, layers, range.
   Paper facts only from the paper. LTF rules only from KJ's academy guides, saved as `pipeline/site/ltf_guides/<slug>.txt`
   (regimes and vrp are summarised in the site's `concepts.js`; older notes in `pipeline/site/LTF_NOTES.md`).
   Link each card to https://app.coreconvexity.app/ltf/academy/guides/<slug>. Add `ltf.src` = guide name(s).
4. Publish to the site URL: `file_path` = the saved page file, `files` = `{"data/<id>.js": …,
   "audio/<id>.mp3": {"from": …, "contentType": "audio/mpeg"}, "papers.js": …, "concepts.js": …}`.
   Files left out are kept.

---------------------------------------------------------------------------------------------
## Catch-up rule (check every run)

- A `done` queue doc with no `youtube` field: do step 3b, then produce a short **"Second
  Opinion" addendum** (5–10 min, same theme, its own spec `specs/<id>_addendum.json`), and
  send it as an extra part.
- A `done` queue doc with no matching doc in the Question Vault: do step 7.
- A `done` + `voice: "v2"` paper missing from the Paper Academy site's `papers.js`: add it (site section).
- p01 (Jones & Shemesh) already has questions in the vault; its video lacks the YouTube
  perspective. Good candidate: "Does Theta Decay on Weekends?" by Canadian Options Trader
  (youtube id wzhOpe9bUiI). It argues weekend decay comes out at random times set by order
  flow, while the paper finds a systematic pattern. Find others too.

---------------------------------------------------------------------------------------------
## Side task: review KJ's second reading folder (do once, while renders run)

KJ's Drive folder `14FZWupuCHeddbM8WO0ImbYuS0djQdw8l` holds more papers (e.g. IMF WP/19/282
"Labor Market Dynamics: A Hidden Markov Approach"). KJ asked for a recommendation on each
before anything is produced from it.
- Check DB doc `tasks/review_folder2`. If its `status` is `done`, skip this section.
- Otherwise, while a part renders in the background, page through the folder with
  `search_files` (`parentId = '14FZWupuCHeddbM8WO0ImbYuS0djQdw8l'`, snippetVerbosity BRIEF; the API
  can return one file per page, so follow `nextPageToken` until it is absent). For each file
  note title, authors, year, topic, rough length, and whether it is a research paper, a
  book chapter, slides, etc.
- Recommend per file: **Full video** (same in-depth method, give an estimated length),
  **Short video** (10–15 min, for thin or narrow papers), or **Other format** (name it: a
  written brief, a reference sheet, slides) with a one-line reason tied to KJ's trading
  (NQ intraday, options/dealer positioning, macro). Flag anything off-topic.
- Save results as docs in collection `review` (id = Drive file id; fields title, topic,
  recommendation, est_minutes, reason) and set `tasks/review_folder2` to
  `{status: "done", finished: <time>}`. Send KJ one SendUserMessage: a compact table of
  the recommendations, asking which ones to add to the queue. Do not add them yourself.

---------------------------------------------------------------------------------------------
If usage runs out mid-run: nothing special is needed — state is in the DB, spec is
published, sent parts are recorded; the next scheduled run resumes.

---------------------------------------------------------------------------------------------
## Spec schema (`specs/<id>.json`)

```json
{"short": "Jones & Shemesh · **JF 2018**",           // HUD brand text (**bold**)
 "chapters": [ { "label": "Result", "layout": "bars", "say": ["sentence", {"say":"...","show":"..."}], ... } ]}
```
Text fields accept `*orange*`, `**bold**`, `\n`. Timing fields (`at`) accept a number of
seconds into the chapter, or `"sN"` = start of sentence N (0-based), or `"sN+1.5"`.
Optional on any chapter: `"broll": "candles" | "chain" | "wave" | "surface"`, `"hold": secs`.

| layout | fields |
|---|---|
| hero | eyebrow, title, titleSize, subtitle, cards[{h,p,at}], pills[{text,at,hl,strike}] |
| close | lines[{text,size,at}], footer, footerAt |
| quote | eyebrow, quote, size, attrib, pills |
| points | eyebrow, title, cards[{h,p,at,hl,span}], cols, rule, ruleLabel, ruleAt |
| stats | eyebrow, title, stats[{label,value,note,accent(o/ok/warn/fix/ink),size,span,at,hl,count:false}], cols, footnote |
| bars | eyebrow, title, chart{label,unit,dec,plus,series[{name,color}],groups[{label,values[],at,hl}],min,max,note,legend,h}, side[stat or card] |
| hbars | eyebrow, title, chart{label,unit,dec,items[{label,value,at,hl,color}],labelW}, side |
| line | eyebrow, title, chart{label,x[],series[{name,values[],color,dash,dots,at}],unit,dec,min,max,bands[{from,to,label}],marks[{x,label,at}],endLabels,draw}, side |
| table | eyebrow, title, tableLabel, columns[], rows[{cells[],at,hl}], rowsAt, rowStep, footnote, rule, signColor:false |
| flow | eyebrow, title, nodes[{h,p,at,hl}], footer |
| checklist | eyebrow, title, items[{h,p,verdict(ok/warn/fix),tag,strike,at}], cols |
| equation | eyebrow, title, eq, eqLabel, eqSize, terms[{h,p,at}], rule |
| compare | eyebrow, title, left{h,items[],hl,color,at}, right{...}, rule |
| timeline | eyebrow, title, events[{date,h,p,at}] (≤ 6) |
| split | eyebrow, title, left[card or stat], right[card or stat] |

Colours: `o` orange, `ok` green, `warn` amber, `fix` coral, `blue`, `mut`, `ink`, `o2` dim orange.
Fit: content area ≈ 1580 × 790 px; keep cards to ≤ 40 words, ≤ 6 cards, tables ≤ 8 rows.
Subtitles render the sentence being spoken, so on-screen text should be the *key facts*,
not a transcript.
