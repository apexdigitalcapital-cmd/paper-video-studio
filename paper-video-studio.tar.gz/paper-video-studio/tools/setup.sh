#!/bin/bash
# One-time per session: installs TTS, Chromium renderer, fonts, models. Idempotent.
set -e; S=/home/claude/studio
pip install --break-system-packages -q kokoro-onnx soundfile scipy 2>&1 | grep -v WARN || true
mkdir -p $S/models && cd $S/models
[ -s kokoro-v1.0.onnx ] || curl -sSL -o kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
[ -s voices-v1.0.bin ] || curl -sSL -o voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
cd $S/tools && [ -d node_modules/puppeteer-core ] || (npm init -y >/dev/null; npm i puppeteer-core @sparticuz/chromium @fontsource/inter @fontsource/jetbrains-mono 2>&1 | tail -1)
echo "setup ok"
