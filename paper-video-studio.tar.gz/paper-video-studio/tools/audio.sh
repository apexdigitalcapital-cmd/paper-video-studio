#!/bin/bash
# Usage: audio.sh <workdir>   (needs voice_raw.wav + timeline.json) -> mix.wav
set -e; WD=$1; T=$(dirname "$0")
python3 $T/make_music.py $WD
ffmpeg -y -loglevel error -i $WD/voice_raw.wav -af "aresample=44100,highpass=f=70,equalizer=f=140:t=q:w=1:g=1.5,equalizer=f=350:t=q:w=1.5:g=-1.5,equalizer=f=4500:t=q:w=1.5:g=1,deesser=i=0.3,acompressor=threshold=-22dB:ratio=1.8:attack=15:release=250,loudnorm=I=-16:TP=-1.5:LRA=9" -ar 44100 $WD/voice.wav
ffmpeg -y -loglevel error -i $WD/voice.wav -i $WD/music.wav -filter_complex "[1:a]volume=0.55[m];[0:a]asplit=2[v][sc];[m][sc]sidechaincompress=threshold=0.03:ratio=6:attack=40:release=600[md];[v][md]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.95" -ar 44100 -ac 2 $WD/mix.wav
echo "audio ok"
