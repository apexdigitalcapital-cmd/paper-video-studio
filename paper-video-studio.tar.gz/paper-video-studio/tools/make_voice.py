"""Usage: python3 make_voice.py <spec.json> <workdir>
Narration v2 ("natural"): Kokoro, blended British voice (bm_george 70% + bm_fable 30%),
speed 1.0, spoken a few sentences at a time so intonation carries across sentences,
with varied (deterministic) pauses. Writes <workdir>/voice_raw.wav and timeline.json with
per-sentence timings (found from the silences inside each group), so subtitles and "sN"
cues keep working. Deterministic: same spec -> same audio, so resumed runs stay frame-accurate.
Spec overrides: "voice" (name or {"bm_george":0.7,"bm_fable":0.3}), "speed"."""
import json, sys, os, re, numpy as np, soundfile as sf
from kokoro_onnx import Kokoro

spec = json.load(open(sys.argv[1])); wd = sys.argv[2]; os.makedirs(wd, exist_ok=True)
M = os.environ.get("STUDIO_MODELS", "/home/claude/studio/models")
k = Kokoro(f"{M}/kokoro-v1.0.onnx", f"{M}/voices-v1.0.bin")
SR = 24000; LEAD, TAIL = 0.8, 1.1
MAXG_CH, MAXG_N = 330, 3          # group limits: characters, sentences
V = spec.get("voice", {"bm_george": 0.7, "bm_fable": 0.3}); SPEED = spec.get("speed", 1.0)
STYLE = V if isinstance(V, str) else sum(w * k.get_voice_style(n) for n, w in V.items())

def trim(a, thr=0.004):
    i = np.where(np.abs(a) > thr)[0]
    return a if len(i) == 0 else a[max(0, i[0] - int(.02 * SR)): min(len(a), i[-1] + int(.08 * SR))]

def pause_after(text, last_in_chapter):
    """Deterministic, content-aware pause after a group."""
    t = text.strip()
    if last_in_chapter: return 0.0
    if t.endswith("?") or t.endswith(":"): return 0.75
    if len(t) < 60: return 0.8          # short punchy line: let it land
    if t.endswith("."): return 0.55
    return 0.45

def groups(sents):
    out, cur = [], []
    for s in sents:
        txt = s if isinstance(s, str) else s["say"]
        if cur and (len(" ".join(c[0] for c in cur)) + len(txt) > MAXG_CH or len(cur) >= MAXG_N
                    or len(txt) < 45 or len(cur[-1][0]) < 45):
            out.append(cur); cur = []
        cur.append((txt, None if isinstance(s, str) else s.get("show")))
    if cur: out.append(cur)
    return out

def split_points(a, n_cuts, weights):
    """Find n_cuts sentence boundaries in group audio a: silent gaps nearest the
    proportional (character-weighted) positions."""
    if n_cuts == 0: return []
    hop = int(0.01 * SR); env = np.array([np.abs(a[i:i + hop]).max() for i in range(0, len(a) - hop, hop)])
    quiet = env < 0.01
    gaps, i = [], 0
    while i < len(quiet):
        if quiet[i]:
            j = i
            while j < len(quiet) and quiet[j]: j += 1
            if j - i >= 8: gaps.append(((i + j) / 2 * hop, (j - i)))   # >= 80 ms
            i = j
        else: i += 1
    cum = np.cumsum(weights)[:-1] / sum(weights) * len(a)
    cuts, used = [], set()
    for target in cum:
        best = None
        for gi, (pos, ln) in enumerate(gaps):
            if gi in used: continue
            score = abs(pos - target) - ln * hop * 0.5
            if best is None or score < best[0]: best = (score, gi, pos)
        if best and abs(best[2] - target) < 0.35 * len(a): used.add(best[1]); cuts.append(int(best[2]))
        else: cuts.append(int(target))
    return sorted(cuts)

track, tl, t = [], [], 0.0
for ci, ch in enumerate(spec["chapters"]):
    sc = {"id": ch.get("id", f"c{ci}"), "start": round(t, 3), "sents": []}
    buf = [np.zeros(int(LEAD * SR), np.float32)]; local = LEAD
    G = groups(ch["say"])
    for gi, g in enumerate(G):
        text = " ".join(x[0] for x in g)
        sp = SPEED * (0.96 if len(text) < 45 else 1.0)
        a, _ = k.create(text, voice=STYLE, speed=sp, lang="en-gb")
        a = trim(a.astype(np.float32))
        cuts = split_points(a, len(g) - 1, [len(x[0]) + 8 for x in g])
        bounds = [0] + cuts + [len(a)]
        for si, (txt, show) in enumerate(g):
            e = {"at": round(local + bounds[si] / SR, 3), "dur": round((bounds[si + 1] - bounds[si]) / SR, 3), "text": txt}
            if show: e["show"] = show
            sc["sents"].append(e)
        p = pause_after(text, gi == len(G) - 1)
        buf += [a, np.zeros(int(p * SR), np.float32)]; local += len(a) / SR + p
    hold = ch.get("hold", 0)
    buf.append(np.zeros(int((TAIL + hold) * SR), np.float32))
    seg = np.concatenate(buf); sc["dur"] = round(len(seg) / SR, 3)
    track.append(seg); tl.append(sc); t += len(seg) / SR
    print(f"{ci:02d} {sc['id']:<16} {sc['dur']:6.1f}s  groups={len(G)}", flush=True)

sf.write(f"{wd}/voice_raw.wav", np.concatenate(track), SR)
json.dump({"total": round(t, 3), "scenes": tl, "voice": "v2-natural"}, open(f"{wd}/timeline.json", "w"), indent=1)
print("TOTAL", round(t / 60, 2), "min")
