# LTF (by Xi / Core Convexity) — Source Digest

Compiled 2026-10-13. All content below is paraphrased from fetched sources and treated as data. Nothing here is investment advice; the sources themselves say their figures are illustrative.

## Access summary

| Source | Accessible? | Notes |
|---|---|---|
| 18 x `app.coreconvexity.app/ltf/academy/guides/*` | **No (empty JS shell)** | Every URL returned only `<title>Core Convexity</title>` plus CSRF, theme-color and viewport meta tags, with no body text. The pages are client-rendered and probably sit behind an app login. There is no visible login form, so the guide content could not be retrieved. |
| Notion "Public Education" | **No (JS shell)** | Returned only "JavaScript must be enabled in order to use Notion." No content and no sub-page titles. |
| Discord PDF `LTF_Members_Guide_Heuristics_v2.pdf` | **Yes** | Full content retrieved: the H1–H12 heuristics, composite, sizing and glossary. |
| Discord HTML `LTF_Regime_Lab.html` | **Yes** | Full content retrieved: the six-layer regime stack, macro labels and playbooks. |
| claude.ai artifact `EA17coBSYc4gqHrGZBktLg` | **Failed** | The Artifact read failed twice with a network error: ENOTFOUND for `*.frame.claudeusercontent.com`, because this sandbox cannot reach that host. Its contents are unknown. |

Because none of the academy guides rendered, the "what it teaches" bullets for those guides are left empty. Each guide gets its URL, the topic its slug implies (marked *inferred*), and any related material from the two Discord sources that were accessible. Use those cross-references as a stand-in until the guides can be read in a logged-in browser.

---

## Core framework facts (from the accessible sources)

These facts come from the PDF and the Regime Lab. They are useful context for every guide below.

- **LTF composite (0–100)** = **L × 0.40 + T × 0.35 + F × 0.25**.
  - **L = Logistics** (40%) has these sub-weights: GEX state 35%, OI concentration 25%, dark-pool alignment 20%, skew verdict 20%.
  - **T = Time/Regime** (35%) is split T_fast 55% and T_slow 45%.
    - T_fast inputs: GEX sign, flip distance, skew slope, term-structure shape.
    - T_slow inputs: curve 35%, credit 35%, inflation 20%, energy 10%.
  - **F = Frequency** (25%) covers flow direction, netflow, sweep confirmation, and the number of prior reactions at the level.
- **Hard gates.** Both must pass, and neither can be overridden:
  - **Cluster score ≥ 7** (H8).
  - **Composite ≥ 60** (H9).
- **Cluster score** is the sum of these components:
  - GEX wall +3
  - OI wall +2
  - Dark-pool anchor +2
  - VWAP alignment +1
  - DEX transition +1
  - Volume-profile node +1
  - +1 per prior reaction
- **Cluster tiers:** Elite 10+, Tradeable 7–9, Weak 4–6, None 0–3.
- **Sizing (composite → Kelly):**
  - Below 60: no trade
  - 60–69: ¼ Kelly
  - 70–79: ½ Kelly
  - 80–89: full Kelly
  - 90–100: full Kelly, never oversized
- **Extreme-regime cap.** H12 caps the whole book at **20% Kelly**.
- **Inconsistency in the sources.** The glossary and Regime Lab use different grade bands from the sizing table above: A is 75+ and B is 60–74 (half Kelly).

---

## 1. Yield curves & spreads
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/yield-curves-spreads
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* the yield-curve shape and term spreads as T_slow macro inputs.
- **Corroborating facts (Regime Lab and PDF):**
  - The curve carries 35% of T_slow.
  - Curve shape helps define the macro regimes: normal, bull steepener, inverted/flat.
  - **Un-inversion, not inversion, is the alarm.** It leads recession by about 11–23 months.
  - The "recession proximate" regime is a bull steepener after un-inversion.
- **Connects to:** regimes, credit spreads, time (T_slow), Kelly caps.

## 2. Energy prices
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/energy-prices
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* WTI/energy as a macro and inflation input.
- **Corroborating facts:**
  - Energy is 10% of T_slow.
  - WTI bands by regime:
    - Expansion: $70–95
    - Soft landing: below $90
    - Restrictive plateau: $85–95
    - Sticky inflation: $95+
  - **WTI above $110 for 5 sessions triggers H12**, a 20% Kelly cap. It clears when WTI is below $100 for 5 sessions or on de-escalation.
- **Connects to:** regimes, inflation, H12 override, sector rotation.

## 3. Expected / probabilistic moves
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/expected-probabilistic-moves
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* the options-implied expected move and probability ranges.
- **Corroborating facts:** Neither Discord source mentions the expected move.
- **Connects to (inferred):** IV vs RV, VRP, open interest and walls, options expiry.

## 4. Kelly criterion
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/kelly-criterion
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* position sizing.
- **Corroborating facts:**
  - The composite-to-Kelly bands (Core facts above).
  - H5 (VVIX above 100) compresses seller size by 25–50%.
  - H12 caps the whole book at 20% Kelly.
  - Regime caps:
    - Restrictive plateau: ½ Kelly on longs
    - Sticky inflation: ½ Kelly; full Kelly on bearish
    - Recession proximate: ½ Kelly on longs
    - Forced-neutral playbook: ¼ Kelly maximum
  - Crash failure mode for GEX: drop to ¼ Kelly and require flow confirmation.
- **Connects to:** composite scoring, regimes, VVIX, cluster scoring.

## 5. IV vs RV
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/iv-vs-rv
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* implied versus realized volatility.
- **Corroborating facts (IVR rules):**
  - IVR = (IV − 52-week low) / (52-week high − 52-week low).
  - **IVR below 25 = cheap.** Buy options and debit structures (H3).
  - **IVR above 50 = expensive.** Sell premium and credit structures (H4).
  - IVR 25–50 is neutral.
  - H3 and H4 are suspended if VIX doubles in under 5 sessions or VVIX is above 130.
- **Connects to:** VRP, VVIX, expected move, regimes.

## 6. Sector rotation
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/sector-rotation
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* sector leadership across the cycle.
- **Corroborating facts:** The only mention is "defensive sector exposure", permitted in the Extreme Defensive playbook.
- **Connects to:** regimes, alpha vs beta, energy.

## 7. Dark pools
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/dark-pools
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* dark-pool prints as institutional anchors.
- **Corroborating facts:**
  - Dark-pool alignment is 20% of the L-axis.
  - A dark-pool anchor adds +2 to the cluster score.
  - Microstructure layer (L6) inputs: dark-pool premium, dark vs lit VWAP, closing-auction imbalance.
  - L6 refines timing and stops but cannot create a trade.
  - The PDF cites a "Dark Pools guide" and a vault note, "Dark Pool VWAP".
- **Connects to:** cluster scoring, open interest, frequency scoring.

## 8. Frequency scoring
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/frequency-scoring
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* the F-axis of the composite.
- **Corroborating facts:**
  - The F-axis is 25% of the composite. It covers flow direction, netflow, sweep confirmation, and prior-reaction frequency.
  - **H7: 3 or more sweeps at the same strike and direction within 90 minutes = institutional activation.**
  - Sweeps are filtered or downgraded when they are:
    - mixed-direction
    - deep ITM (treated as hedges)
    - single sweeps or straddles
    - in conflict with netflow
  - A sweep plus an OI spike at the same strike is the highest-confidence signal.
- **Connects to:** open interest, dark pools, cluster scoring.

## 9. Alpha vs beta
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/alpha-vs-beta
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* separating skill-driven return from market exposure.
- **Corroborating facts:** The Extreme Defensive playbook prohibits "directional long-equity beta".
- **Connects to:** sector rotation, Kelly sizing, regimes.

## 10. Time
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/time
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* the T-axis (Time/Regime). It may also cover DTE and seasonality.
- **Corroborating facts:**
  - The T-axis is 35% of the composite, split T_fast (options mechanics) and T_slow (macro).
  - DTE regimes:
    - 0DTE: extreme gamma, pin setups only
    - 1–5 DTE: pin trades and strangles inside the walls
    - 7–21 DTE: full composite with defined-risk spreads
    - 30–60 DTE: vega dominates and IVR selects the strategy
    - Over 60 DTE: LEAPS and vega hedges; re-check walls every 5 sessions
  - **H11: DTE ≤ 5 means gamma dominates, so no theta-fade plays.**
  - Lead times: credit leads equities by 2–4 weeks; un-inversion leads recession by 11–23 months.
  - No seasonality content was found in either source.
- **Connects to:** regimes, OPEX, open interest, expected move.

## 11. VVIX
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/vvix
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* the volatility of VIX.
- **Corroborating facts:**
  - VVIX is the implied volatility of VIX options.
  - **Above 80 = warning.**
  - **Above 100 fires H5:** compress seller size by 25–50% and cap the seller composite at 70. This applies regardless of IVR.
  - Above 130 suspends H3 and H4.
  - Crisis vol is defined by VVIX above 100.
- **Connects to:** IV vs RV, VRP, Kelly sizing, regimes.

## 12. Open interest
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/open-interest
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* OI walls, GEX, dealer positioning and the gamma flip. The PDF cites the "LTF Open Interest Guide" as its source for the GEX flip.
- **Corroborating facts:**
  - **GEX:**
    - **Positive GEX means dealers buy dips and sell rips.** This favors mean reversion and short premium.
    - **Negative GEX means dealers chase price.** This favors trend and directional trades.
    - Bands: ±$500M is the flip or transition zone (composite capped at 70), ±$1B is strong, ±$2B is extreme.
  - **H1–H2 (flip):**
    - H1 reads the GEX sign.
    - H2 fires when price crosses the zero-gamma flip, signalling a regime change. It is the most-watched heuristic.
    - A flip that reverses within 30 minutes is treated as fake.
  - **H6 (walls):** spot within 0.5% of a call or put wall triggers a cluster score.
  - **H10 (max pain):** spot within 0.5% of max pain with DTE ≤ 2 creates a pin bias. Favor iron condors or butterflies.
  - **DEX:** shows whether dealers are long or short the underlying. Platforms may report its sign differently.
  - **When the GEX heuristics stop working:**
    - Thin volume (under 50% of the 20-day average) suspends them.
    - They misled in 2020 and 2022.
- **Connects to:** cluster scoring, OPEX and pinning, delta hedging, frequency scoring.

## 13. Credit spreads & sparklines
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/credit-spreads-sparklines
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* HY OAS credit spreads and their trend sparklines.
- **Corroborating facts:**
  - Credit is 35% of T_slow.
  - HY OAS bands by regime:
    - Soft landing: below 300
    - Expansion: 300–500
    - Restrictive plateau: 300–450
    - Sticky inflation: 350–500
    - Recession proximate: above 450
  - **Above 500 bps triggers H12**, a 20% Kelly cap. It clears when OAS is below 450 for 5 sessions.
  - Playbook stops:
    - Optimal seller: stop if OAS widens 50+ bps in 2 weeks.
    - Optimal buyer: stop if OAS contracts 50+ bps.
    - VIX calls are permitted if OAS is above 400.
  - Credit leads equities by 2–4 weeks.
  - The Macro Terminal port 5004 is the credit module.
- **Connects to:** yield curve, regimes, Kelly sizing.

## 14. Cluster scoring
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/cluster-scoring
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* the strike-level confluence score.
- **Corroborating facts:**
  - Seven components: GEX wall +3, OI wall +2, dark-pool anchor +2, VWAP +1, DEX transition +1, HVN +1, and +1 per prior reaction.
  - Tiers: 10+ elite, 7–9 tradeable, 4–6 weak, 0–3 none.
  - **H8: a cluster score below 7 is a hard stop.**
  - This is layer L4 of the Regime Lab stack.
- **Connects to:** open interest, dark pools, frequency scoring, composite and Kelly.

## 15. Insider & Congress
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/insider-congress
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* insider (Form 4) trades and congressional trading disclosures as signals.
- **Corroborating facts:** Neither Discord source mentions this topic.
- **Connects to (inferred):** frequency scoring, dark pools, alpha.

## 16. VRP (variance risk premium)
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/vrp
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* implied variance minus realized variance, as the premium earned by sellers.
- **Corroborating facts (Regime Lab only):**
  - VRP is described as high, moderate, low or negative depending on the regime. It can turn negative in crisis vol.
  - The source uses the terms "skew VRP" and "term VRP".
  - The Optimal Seller playbook stops when VRP is below +2.
  - The PDF does not mention VRP.
- **Connects to:** IV vs RV, VVIX, regimes, expected move.

## 17. Regimes
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/regimes
- **Accessible?** No (empty JS shell). The Regime Lab HTML (Section 21) is an interactive edition of "Members Guide – Regimes v1.0", which is very likely the same material.
- **What it teaches (from the Regime Lab):**
  - Read the regime before reading any signal: "the tide versus the waves".
  - The six-layer stack is described in Section 21.
  - Six macro labels set composite ceilings and Kelly caps.
- **Connects to:** every other guide. Regimes are the top gate.

## 18. LTF by Xi — the official framework
- **URL:** https://app.coreconvexity.app/ltf/academy/guides/ltf-by-xi-the-official-framework
- **Accessible?** No (empty JS shell).
- **What it teaches:** Content unavailable. *Inferred:* the master overview of the framework. The PDF cites a primary source, "LTF By XI Official 2026.pdf", and a synthesis note, "LTF_Master_Guide_2026".
- **Corroborating facts:** See Core framework facts above: the L/T/F composite, the gates, sizing and H1–H12.
- **Connects to:** all guides. This should be the default link on a card about the overall framework.

## 19. Notion — Public Education
- **URL:** https://well-shark-618.notion.site/Public-Education-262ba20c0fea80e0a8f7e0d7ac7abf5e
- **Accessible?** No (JS shell). It returned only "JavaScript must be enabled in order to use Notion."
- **What it teaches:** Unknown. No sub-page titles could be retrieved.

## 20. Discord PDF — LTF Members Guide: Heuristics v2
- **URL:** https://cdn.discordapp.com/attachments/1553216958546055289/1556447674968973393/LTF_Members_Guide_Heuristics_v2.pdf?backend=b2&ex=6acf671b&is=6ace159b&hm=d1d63e09f68484d09e9ca193ae1d27642e9c93bba9d10c24cb3837c64ba37648&
- **Accessible?** Yes. Its metadata says v1.0, updated 2026-05-22, members-only. Discord CDN links expire, so this link may stop working.
- **What it teaches:**
  - **Purpose.** Twelve fast "triage" heuristics, H1–H12, screen setups before the full composite is scored. Heuristics take seconds to apply; the composite takes minutes. The heuristics are filters, not trade signals.
  - **H1–H2 (GEX):**
    - H1: positive GEX means fade extremes near the walls; negative GEX means trend-follow.
    - H2: a zero-gamma flip cross means switch modes.
  - **H3–H5 (volatility):**
    - H3: IVR below 25, buy premium.
    - H4: IVR above 50, sell premium.
    - H5: VVIX above 100, cut seller size by 25–50%.
  - **H6–H7 (flow):**
    - H6: spot within 0.5% of a wall triggers a cluster score.
    - H7: 3 or more same-strike, same-direction sweeps within 90 minutes.
  - **H8–H9 (hard gates):** cluster score below 7 = stop; composite below 60 = stop.
  - **H10–H11 (timing):**
    - H10: max-pain pin when spot is within 0.5% and DTE ≤ 2.
    - H11: DTE ≤ 5 means no theta-fade.
  - **H12 (override):**
    - After monthly OPEX: cut gross 25–50% for 2–5 sessions.
    - After quarterly OPEX: cut gross 50% for 3–7 sessions, and pre-stage hedges 2 days before.
    - HY OAS above 500, VIX above 30 sustained, or WTI above $110 for 5 days: 20% Kelly cap.
  - **Sizing.** Composite bands map to Kelly fractions, as listed in Core facts.
  - **When heuristics break:**
    - Thin volume
    - A fake flip (reversed within 30 minutes)
    - VIX doubling or VVIX above 130
    - Sweeps above 5× normal in the last 90 minutes, which unpin a pin trade: exit and do not average down
    - Crisis correlation going to 1
  - **Daily pre-open checklist (5–8 minutes).** Run in this order and stop at any hard stop: H12, H1/H2, H3/H4, H5, H10/H11, H6, H7, then the H8/H9 gates.
  - **Tools and data named:** Macro Terminal (ports 5001, 5003, 5004 for credit), Tradytics, CBOE LiveVol, OPRA chains, and the Jarvis Obsidian vault notes.
  - **Inconsistencies flagged:**
    - Grade bands differ between sections.
    - The 60–69 band is ¼ Kelly in one place and ½ Kelly in another.
    - The 20% cap is flagged "verify".
- **Connects to:** open interest, VVIX, IV vs RV, cluster scoring, frequency, time, Kelly, credit, energy, regimes.

## 21. Discord HTML — LTF Regime Lab
- **URL:** https://cdn.discordapp.com/attachments/1521890852719300748/1548803647972970626/LTF_Regime_Lab.html?ex=6acff04d&is=6ace9ecd&hm=74213595e80a4fb46c14268981009c0ebaf9459d8a22920e722a55d1cb9cb4fe&
- **Accessible?** Yes. It is an interactive edition of "Members Guide – Regimes v1.0". The link may expire.
- **What it teaches:**
  - **Six-layer stack**, evaluated top-down. Higher layers cap or block lower ones, and the layers combine multiplicatively:
    1. **L1 Macro (T_slow):** curve 35%, credit 35%, inflation 20%, energy 10%.
    2. **L2 Vol structure (T_fast):** GEX, skew, term structure, IVR, VVIX.
    3. **L3 Dealer exposure:** GEX and DEX.
    4. **L4 Strike cluster.**
    5. **L5 Flow:** OI, sweeps, netflow, put/call ratio.
    6. **L6 Microstructure:** dark-pool premium, dark vs lit VWAP, closing-auction imbalance, ATM spread. A wide spread caps the composite at 70.
  - **Macro labels** (composite ceiling, Kelly cap):
    - Expansion: no ceiling; full Kelly.
    - Soft landing: no ceiling; full Kelly; favor short vol.
    - Restrictive plateau: longs capped at 75; ½ Kelly on longs.
    - Sticky inflation (PCE above 3%, WTI $95+): longs capped at 70.
    - Recession proximate (un-inversion steepener, OAS above 450, labor softening): longs capped at 60; bearish trades up to 90.
    - Extreme: 20% Kelly on the whole book.
  - **Vol regimes:**
    - High seller: GEX positive and far from flip, steep skew, contango, IVR above 50.
    - Moderate seller.
    - Neutral: GEX near flip, flat skew and term structure.
    - Buyer: GEX negative, backwardation, IVR below 25.
    - Crisis: extreme negative GEX, steep backwardation, VVIX above 100; VRP may be negative.
  - **Interpretation rules:**
    - Normal put skew is not bearish. Only a two-wing smile or a fast change in skew is a warning.
    - Backwardation into a known event (CPI, FOMC, earnings) is expected, not a sign of fear.
  - **Four playbooks** (permitted structures, sizing, stops):
    - **Optimal Seller:** condors between the walls, OTM put spreads, covered writes; full Kelly at 80+. Stops: GEX flip, VRP below +2, OAS widening 50 bps or more in 2 weeks.
    - **Optimal Buyer:** straddles at high-OI strikes, 30–60 DTE put spreads, VIX calls if OAS is above 400; ½ Kelly.
    - **Forced Neutral:** wait; if forced, calendars or iron butterflies at max pain; ¼ Kelly maximum.
    - **Extreme Defensive:** long vol, gold and defensives; no new short vol; 20% Kelly.
  - **Transitions.** Pre-stage size cuts on early warnings: GEX drifting toward the flip, OAS rising fast, a flattening term structure, or OPEX within 5 sessions. Close pin-dependent trades 2 days before OPEX, and cut gross 25% during the post-OPEX OI reset.
  - **Interactive tools:**
    - Macro regime picker
    - Vol regime picker
    - GEX explorer
    - GEX/DEX combiner
    - Cluster builder
    - Flow classifier
    - Stack simulator, with presets including the "wrong-regime trap"
    - Quiz and glossary
- **Connects to:** regimes, yield curve, credit, energy, VIX/VVIX, VRP, OI/GEX, cluster, frequency, dark pools, OPEX, Kelly.

## 22. claude.ai artifact EA17coBSYc4gqHrGZBktLg
- **URL:** https://claude.ai/artifact/EA17coBSYc4gqHrGZBktLg
- **Accessible?** **Failed.** The Artifact tool's read was attempted twice. Both attempts returned a network error: `ENOTFOUND 6a88911b-...frame.claudeusercontent.com`, because the sandbox has no outbound access to that host. Its contents are unknown. Re-read it from a session that can reach `*.frame.claudeusercontent.com`.

---

## Topic → guide URL map

Base URL: `https://app.coreconvexity.app/ltf/academy/guides/`. "Primary" is the best-matching guide by slug. Because no guide body was readable, these slug matches are unverified. "Also" lists secondary guides or accessible sources that cover the topic.

| Topic | Primary LTF guide | Also |
|---|---|---|
| Yield curve | `yield-curves-spreads` | `regimes`; Regime Lab (L1) |
| Term spread (2s10s etc.) | `yield-curves-spreads` | `regimes` |
| Credit spreads (HY OAS) | `credit-spreads-sparklines` | `regimes`; PDF H12; Regime Lab |
| VIX | `vvix` (closest) | `regimes`, `iv-vs-rv`; PDF H12 (VIX >30) |
| VVIX | `vvix` | PDF H5; Regime Lab L2 |
| Implied vs realized vol / IV rank | `iv-vs-rv` | `vrp`; PDF H3/H4 |
| Variance risk premium | `vrp` | `iv-vs-rv`; Regime Lab playbooks |
| Regimes (macro + vol) | `regimes` | `ltf-by-xi-the-official-framework`; Regime Lab (whole page) |
| FOMC / macro events | `regimes` (closest; no dedicated guide found) | `time`; Regime Lab (event backwardation) |
| Open interest / dealer gamma (GEX) / positioning (DEX) | `open-interest` | `cluster-scoring`; PDF H1/H2/H6 |
| Options expiry / OPEX / max-pain pinning | `open-interest` | `time`; PDF H10/H12 |
| Delta hedging (dealer hedging) | `open-interest` | `regimes`; PDF Section 3 |
| Expected move | `expected-probabilistic-moves` | `iv-vs-rv` |
| Kelly sizing | `kelly-criterion` | `ltf-by-xi-the-official-framework`; PDF Section 9 |
| Alpha vs beta | `alpha-vs-beta` | `sector-rotation` |
| Sector rotation | `sector-rotation` | `regimes`, `energy-prices` |
| Dark pools | `dark-pools` | `cluster-scoring`; Regime Lab L6 |
| Energy / oil (WTI) | `energy-prices` | `regimes`; PDF H12 |
| Time / DTE / seasonality | `time` | `open-interest`; PDF H11 and Section 7 (no seasonality content found) |
| Insider / Congress trades | `insider-congress` | none |
| Composite score (L/T/F) | `ltf-by-xi-the-official-framework` | `cluster-scoring`, `frequency-scoring` |
| Cluster / confluence score | `cluster-scoring` | `open-interest`, `dark-pools` |
| Flow, sweeps, netflow (F-axis) | `frequency-scoring` | `open-interest`; PDF H7 |
| Heuristics H1–H12 | `ltf-by-xi-the-official-framework` | Discord PDF (only source) |
| Skew / term structure | `iv-vs-rv` (closest) | `regimes`; Regime Lab L2 |
| Inflation (core PCE) | `regimes` | `energy-prices` |
