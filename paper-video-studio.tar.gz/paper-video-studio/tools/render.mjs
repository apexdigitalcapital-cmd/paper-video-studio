// Usage: node render.mjs <stage.html> stills <t1,t2,...> <outdir>
//        node render.mjs <stage.html> video <from> <to> <out.mp4>
import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';
import { spawn } from 'child_process';
const [page_, mode] = process.argv.slice(2, 4);
const browser = await puppeteer.launch({ executablePath: await chromium.executablePath(), headless: 'shell',
  args: [...chromium.args.filter(a => !a.includes('angle') && !a.includes('swiftshader') && !a.includes('gpu')), '--disable-gpu', '--hide-scrollbars'] });
const page = await browser.newPage();
await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
page.on('pageerror', e => console.error('PAGEERR', e.message));
await page.goto('file://' + page_); await page.evaluate(() => window.ready); await new Promise(r => setTimeout(r, 300));
if (mode === 'stills') {
  const ts = process.argv[4].split(',').map(Number), od = process.argv[5];
  for (const t of ts) { await page.evaluate(t => { for (let k = Math.max(0, t - 3); k < t; k += .5) window.render(k); window.render(t) }, t);
    await page.screenshot({ path: `${od}/f_${t.toFixed(1)}.jpg`, type: 'jpeg', quality: 85 }); }
} else {
  const from = +process.argv[4], to = +process.argv[5], out = process.argv[6], FPS = 30;
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', '30', '-c:v', 'mjpeg', '-i', '-',
    '-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'animation', '-b:v', '440k', '-maxrate', '620k', '-bufsize', '1240k', '-g', '120', '-pix_fmt', 'yuv420p', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  const cdp = await page.createCDPSession(); const f0 = Math.round(from * FPS), f1 = Math.round(to * FPS);
  await page.evaluate(t => { for (let k = Math.max(0, t - 3); k < t; k += 1 / 30) window.render(k) }, from);
  const t0 = Date.now();
  for (let f = f0; f < f1; f++) { await page.evaluate(t => window.render(t), f / FPS);
    const { data } = await cdp.send('Page.captureScreenshot', { format: 'jpeg', quality: 90, optimizeForSpeed: true });
    if (!ff.stdin.write(Buffer.from(data, 'base64'))) await new Promise(r => ff.stdin.once('drain', r));
    if ((f - f0) % 600 === 0) console.log(out, f - f0, '/', f1 - f0, ((Date.now() - t0) / 1000 | 0) + 's'); }
  ff.stdin.end(); await new Promise(r => ff.on('close', r)); console.log('done', out);
}
await browser.close();
