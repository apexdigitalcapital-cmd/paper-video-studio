#!/bin/bash
# Usage: new_paper.sh <spec.json> <workdir>   -> voice, audio mix, data.js, parts.json, stage.html
set -e; SPEC=$1; WD=$2; T=$(cd $(dirname "$0"); pwd); mkdir -p $WD
python3 $T/make_voice.py $SPEC $WD 2>&1 | grep -vi warn
bash $T/audio.sh $WD
python3 $T/prep.py $SPEC $WD
cp $T/../engine/stage.html $WD/stage.html; ln -sfn $T/node_modules $WD/node_modules
echo "ready: $WD"
