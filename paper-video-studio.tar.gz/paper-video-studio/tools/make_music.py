import json, sys, numpy as np, soundfile as sf
WD = sys.argv[1]
SR = 22050  # low-memory: music bed at 22.05 kHz (ffmpeg resamples in the mix)
tl = json.load(open(f"{WD}/timeline.json"))
T = tl["total"] + 2.0
n = int(T * SR)
t = (np.arange(n, dtype=np.float32) / SR).astype(np.float32)
rng = np.random.default_rng(7)

from scipy.signal import butter, sosfilt  # scipy available?

def lp(x, fc, order=4):
    return sosfilt(butter(order, fc, 'low', fs=SR, output='sos'), x)
def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], 'band', fs=SR, output='sos'), x)

def note(m): return 440.0 * 2 ** ((m - 69) / 12)

# Chord progression (Dm9 - Bbmaj7 - Fadd9 - C6), 8s each, slow & cinematic
chords = [[50, 57, 60, 64, 65], [46, 53, 57, 62, 65], [41, 53, 57, 60, 67], [48, 55, 60, 64, 69]]
CH = 8.0
pad = np.zeros(n, np.float32)
for ci in range(int(T / CH) + 1):
    ch = chords[ci % 4]
    s0 = int(ci * CH * SR); s1 = min(n, int((ci + 1) * CH * SR + 2.5 * SR))
    if s0 >= n: break
    tt = np.arange(s1 - s0) / SR
    env = np.minimum(1, tt / 2.2) * np.clip((CH + 2.5 - tt) / 2.5, 0, 1)
    seg = np.zeros(s1 - s0)
    for m in ch:
        f = note(m)
        for det in (-0.12, 0.0, 0.11):
            ph = rng.uniform(0, 2 * np.pi)
            ff = f * 2 ** (det / 12)
            # soft saw-ish: few harmonics
            seg += (np.sin(2*np.pi*ff*tt+ph) + 0.35*np.sin(4*np.pi*ff*tt+ph) + 0.15*np.sin(6*np.pi*ff*tt+ph)) / 3
    pad[s0:s1] += seg * env
pad = lp(pad, 1400).astype(np.float32)
# sub bass on chord roots
sub = np.zeros(n, np.float32)
for ci in range(int(T / CH) + 1):
    s0 = int(ci * CH * SR); s1 = min(n, int((ci + 1) * CH * SR))
    if s0 >= n: break
    tt = np.arange(s1 - s0) / SR
    f = note(chords[ci % 4][0] - 12)
    env = np.minimum(1, tt / 0.8) * np.clip((CH - tt) / 0.8, 0, 1)
    sub[s0:s1] = np.sin(2 * np.pi * f * tt) * env
# soft pulse (filtered noise ticks on 8ths at 96bpm) — the "data" heartbeat
pulse = np.zeros(n, np.float32)
beat = 60 / 96 / 2
click = bp(rng.standard_normal(int(0.05 * SR)), 2500, 7000) * np.exp(-np.arange(int(0.05 * SR)) / (0.008 * SR))
k = 0
while k * beat < T:
    s = int(k * beat * SR)
    amp = 0.55 if k % 2 == 0 else 0.3
    e = min(n, s + len(click)); pulse[s:e] += click[:e - s] * amp
    k += 1
# kick-ish low thump on beats 1 & 3 (half-time)
thump = np.sin(2*np.pi*np.cumsum(np.linspace(90, 40, int(0.25*SR)))/SR) * np.exp(-np.arange(int(0.25*SR))/(0.07*SR))
k = 0
while k * beat * 4 < T:
    s = int(k * beat * 4 * SR); e = min(n, s + len(thump)); pulse[s:e] += thump[:e-s] * 0.9; k += 1

# arrangement: pulse fades in after the intro, out in the final scene
scenes = tl["scenes"]
start_pulse = scenes[1]["start"]
end_pulse = scenes[-1]["start"]
pe = np.clip((t - start_pulse) / 3, 0, 1) * np.clip((end_pulse + 2 - t) / 4, 0, 1)
music = 0.32 * pad / (np.abs(pad).max() + 1e-9) + 0.22 * sub + 0.16 * pulse * pe
fade = np.clip(t / 3, 0, 1) * np.clip((T - t) / 4, 0, 1)
music *= fade; del fade, pe, pad, sub, pulse

# SFX: whoosh at each scene change + deep boom at title + riser into title
sfx = np.zeros(n, np.float32)
def whoosh(at, dur=1.4, amp=0.5, up=True):
    m = int(dur * SR); x = rng.standard_normal(m)
    tt = np.arange(m) / m
    out = np.zeros(m)
    # sweep band by blocks
    blocks = 40
    for b in range(blocks):
        a0 = b * m // blocks; a1 = (b + 1) * m // blocks
        fr = b / blocks if up else 1 - b / blocks
        fc = 300 + 5000 * fr ** 1.5
        seg = bp(x[max(0,a0-2000):a1], fc*0.6, min(fc*1.6, 20000))[-(a1-a0):]
        out[a0:a1] = seg
    env = np.sin(np.pi * tt) ** 2
    s = int((at - dur * 0.6) * SR); s = max(0, s)
    e = min(n, s + m); sfx[s:e] += (out * env * amp)[:e - s]
def boom(at, amp=0.9):
    m = int(2.5 * SR); tt = np.arange(m) / SR
    x = np.sin(2*np.pi*np.cumsum(np.linspace(70, 28, m))/SR) * np.exp(-tt / 0.6)
    x += lp(rng.standard_normal(m), 200) * np.exp(-tt / 0.3) * 0.6
    s = int(at * SR); e = min(n, s + m); sfx[s:e] += (x * amp)[:e - s]
def blip(at, f=1320, amp=0.18):
    m = int(0.18 * SR); tt = np.arange(m) / SR
    x = np.sin(2*np.pi*f*tt) * np.exp(-tt / 0.035) + 0.5*np.sin(2*np.pi*f*1.5*tt) * np.exp(-tt / 0.02)
    s = int(at * SR); e = min(n, s + m); sfx[s:e] += (x * amp)[:e - s]

for i, sc in enumerate(scenes):
    if i == 0: continue
    whoosh(sc["start"] + 0.15, amp=0.35)
# clock ticks in the cold open (scene 0, first ~4s) and a boom on the title
for j in range(8):
    blip(0.5 + j * 0.5, f=2200, amp=0.08)
boom(scenes[1]["start"] + 0.2)
if len(scenes[-1]["sents"]) > 1: boom(scenes[-1]["start"] + scenes[-1]["sents"][1]["at"] - 0.1, amp=0.6)
# soft UI blips on every sentence start (subtle data-reveal feel)
for sc in scenes:
    for s in sc["sents"][1:]:
        blip(sc["start"] + s["at"] - 0.05, f=1760, amp=0.05)

sfx = lp(sfx, 9000).astype(np.float32)
mix = (music + 0.6 * sfx).astype(np.float32); del music, sfx
mix /= np.abs(mix).max() * 1.05
sf.write(f"{WD}/music.wav", np.stack([mix, mix], 1).astype(np.float32), SR)
print("music", T)
